function render3(f)
   imagesc(reshape(f,64,64))